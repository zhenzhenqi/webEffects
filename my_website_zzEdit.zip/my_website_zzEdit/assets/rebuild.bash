cd assets
npm install        # If you haven't done this yet
npm run deploy     # For production
# OR:
npm run watch      # For development

mix phx.server